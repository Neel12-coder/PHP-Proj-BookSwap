
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.card {
  margin: none;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 30%;
  border-radius: 8px;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

img {
  border-radius: 5px 5px 0 0;
}

.container {
  padding: 2px 16px;
}
button {
    width: 30%;
    background-color: black;
    color: white;
    font-family: Times New Roman;
    font-size:20;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  button:hover {
    background-color: #2E4053;
  }

</style>
</head>
<body>

<p style='font-size:80px;color: blue '>About Us</p>
<div class="card">
  <img src="https://www.w3schools.com/w3images/avatar2.png" alt="Avatar" style="width:100%">
  <div class="container">
    <h4><b>Aditaya Shrivastava</b></h4> 
    <p>Full Stack Developer</p> 
  </div>
</div>
<div>
</div>
<br><br>
<div class="card">
  <img src="https://www.w3schools.com/howto/img_avatar2.png" alt="Avatar" style="width:100%">
  <div class="container">
    <h4><b>Anmol Vaswani</b></h4> 
    <p>Full Stack Developer</p> 
  </div>
</div>
<br><br>
<div class="card">
  <img src="https://www.w3schools.com/howto/img_avatar2.png" alt="Avatar" style="width:100%">
  <div class="container">
    <h4><b>Neelam Somai</b></h4> 
    <p>Full Stack Developer</p> 
  </div>
</div>
</div>
<button onclick="window.location.href='dashlogout.php'">BACK</button>
</body>
</html> 
