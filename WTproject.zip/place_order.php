<?php 
session_start();
$connect = mysqli_connect('localhost','root','');
mysqli_select_db($connect,'bookswap');
if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$count = count($_SESSION["shopping_cart"]);
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_nameofbook'			=>	$_POST["hidden_name"],
				'item_price'		=>	$_POST["hidden_price"],
                'item_quality'		=>	$_POST["hidden_quality"],
                'item_nameofseller' =>  $_POST["hidden_nameofseller"],
                'item_sellerscontactno' => $_POST["hidden_sellerscontactno"]
			);
			$_SESSION["shopping_cart"][$count] = $item_array;
		}
		else
		{
			echo '<script>alert("Book Already Added")</script>';
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_nameofbook'			=>	$_POST["hidden_name"],
			'item_price'		=>	$_POST["hidden_price"],
            'item_quality'		=>	$_POST["hidden_quality"],
            'item_nameofseller' =>  $_POST["hidden_nameofseller"],
            'item_sellerscontactno' => $_POST["hidden_sellerscontactno"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Book Removed")</script>';
				echo '<script>window.location="buy.php"</script>';
			}
		}
	}
}

?>
<!DOCTYPE html>
<html>
	<head>
		<title>Buy Book</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</head>
	<body>
    <?php echo $_SESSION['username']; ?>
			<h3>Order Details</h3>
			<div class="table-responsive">
				<table class="table table-bordered">
					<tr>
						<th width="40%">Name Of Book</th>
						<th width="10%">Quality</th>
                        <th width="20%">Price</th>
                        <th width="40%">Name of seller</th>
                        <th width="40%">Seller's contact no</th>
                        <th width="5%">Action</th>
					</tr>
					<?php
					if(!empty($_SESSION["shopping_cart"]))
					{
						$total = 0;
						foreach($_SESSION["shopping_cart"] as $keys => $values)
						{
					?>
					<tr>
						<td><?php echo $values["item_nameofbook"]; ?></td>
						<td><?php echo $values["item_quality"]; ?></td>
                        <td>Rs. <?php echo $values["item_price"]; ?></td>
                        <td><?php echo $values["item_nameofseller"]; ?></td>
						<td><?php echo $values["item_sellerscontactno"]; ?></td>
						<td><a href="buy.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>
					</tr>
					<?php

						}
					?>
		
					<?php
					}
					?>
						
				</table>
			</div>
		</div>
	</div>
    <br />
    <center><button class="btn btn-success" onclick="window.location.href='dashlogout.php'">Back</button></center>
	</body>
</html>

<?php
if(!empty($_SESSION["shopping_cart"]))
{
    $total = 0;
    foreach($_SESSION["shopping_cart"] as $keys => $values)
    {
        $name =  $values["item_nameofbook"];
        $quality = $values["item_quality"];
        $price = $values["item_price"];
        $seller = $values["item_nameofseller"];
        $contact =  $values["item_sellerscontactno"];
        $buyer = $_SESSION['username'];

        $sql = "INSERT INTO orders(book,quality,price,seller,s_contact,buyer) VALUES('$name','$quality','$price','$seller','$contact','$buyer')";
        mysqli_query($connect,$sql);
    }
}
?>
