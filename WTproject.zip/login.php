<html>
<head>
<title>Login</title>
<style>
body {
  background-image: url("https://images.pexels.com/photos/159621/open-book-library-education-read-159621.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500");
  background-color: #cccccc;
  background-repeat:no-repeat;
  background-size: cover; 
  width:100%;
  height:100%;
}
#paragraph1 {
  font-family: Times New Roman;
  font-size: 50;
  font-weight: bold;
  color: black;
}
#paragraph2 {
  text-align: center;
  font-family: Times New Roman;
  font-size: 30;
  font-weight: bold;
  color: black;
}
label{
font-family:Times New Roman;
font-size:25;
font-weight: bold;
color:black;
}
input[type=text], select {
  width: 40%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=password], select {
  width: 40%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 30%;
  background-color: black;
  color: white;
  font-family: Times New Roman;
  font-size:20;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
input[type=submit]:hover {
  background-color: #2E4053;
}
button {
  width: 30%;
  background-color: black;
  color: white;
  font-family: Times New Roman;
  font-size:20;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
button:hover {
  background-color: #2E4053;
}
.signupbutton {
    text-align: center;
}

.button {
    position: absolute;
}
</style>
<body>
<form align="center" name="myLogin" action="loginval.php" method="post">
<p id="paragraph1">Login</p>
<label for="username">Username</label>
<input name="username" type="text" required>
<br><br>
<label for="password">Password</label>
<input id="passw1" name="password" type="password" required min="8" max="30" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}">
<br><br>
<input type="submit" value="Login">
<button onclick="window.location.href='index.html'">CANCEL</button>

</form>
<br>
<p id="paragraph2">Not a Member?</p>
<br>
<div class="signupbutton">
<button onclick="window.location.href='signup.php'">Sign Up</button>
</div>
</body>
</head>
</html>