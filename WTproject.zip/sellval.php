<?php

session_start();
header('location:sellbook.php');

$con=mysqli_connect('localhost','root','');

mysqli_select_db($con,'bookswap');

$sem=$_POST['semester'];
$nob=$_POST['nameofbook'];
$noa=$_POST['nameofauthor'];
$price=$_POST['price'];
$quality=$_POST['quality'];
$nos=$_POST['nameofseller'];
$scn=$_POST['sellerscontactno'];

$reg="insert into addbooks (semester,nameofbook,nameofauthor,price,quality,nameofseller,sellerscontactno) values ('$sem','$nob','$noa','$price','$quality','$nos','$scn')";
mysqli_query($con,$reg);?>
?>
