<!DOCTYPE html>
<html>
<head>

<style>
button {
    width: 30%;
    background-color: black;
    color: white;
    font-family: Times New Roman;
    font-size:20;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  button:hover {
    background-color: #2E4053;
  }


</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
<h1>QUOTES!!<h1>
<center><div class='a'>
<img src="http://s3.amazonaws.com/media.briantracy.com/blog/wp-content/uploads/2015/12/04093022/make-your-life-a-masterpiece-brian-tracy-motivational-quotes.png" alt="quote" style="width:50%; height: 50%">
</div>
<br>
<div class='a'>
<img src="https://blog.rescuetime.com/wp-content/uploads/2017/12/time-isnt-the-main-thing-1000x486.png" alt="quote" style="width:50%; height: 50%">
</div>
<br>
<div class='a'>
<img src="https://wisdomquotes.com/wp-content/uploads/inspirational-quotes-every-next-level-of-your-life-will-demand-a-different-you-wisdom-quotes-1.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<br>
<div class='a'>
<img src="https://i.pinimg.com/originals/17/f2/78/17f2780263c02096690dddcd185ce359.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<br>
<div class='a'>
<img src="https://static.boredpanda.com/blog/wp-content/uploads/2019/04/famous-people-inspiring-quotes-3b-5cb43958baf96__700.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<br>
<div class='a'>
<img src="https://www.lottoland.co.uk/cms/599aa02b0eb35823c1d8df10/quotes-motivational-hawking.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<br>
<div class='a'>
<img src="https://skyprep.com/wp-content/uploads/2013/07/Alfred_Quotes1.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<br>
<div class='a'>
<img src="https://pakwired.com/wp-content/uploads/2015/05/quote-of-the-day-300x180.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<br>
<div class='a'>
<img src="https://i.pinimg.com/originals/d0/8a/20/d08a20487945334f440a349c2cbd458d.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<br>
<div class='a'>
<img src="https://i0.wp.com/www.rankred.com/wp-content/uploads/2014/08/Inspirational-Quote.jpg?resize=550%2C300" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="https://qph.fs.quoracdn.net/main-qimg-c959b9117da943558a959ef83f274fca.webp" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="https://inspomillionairemind.files.wordpress.com/2018/10/kofi.png?w=736" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRdsF4hetvus7bJIvxkbM-YzpkcQENm9q9zKzDBura0btExttBA7A" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="http://www.everythingmixed.com/wp-content/uploads/inspirational-quotes-09.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="https://i.pinimg.com/originals/3a/b9/fb/3ab9fb3daec155a3fdf03018bf3a3615.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="https://3.bp.blogspot.com/-E7GXcp0szbU/V7rVRgkG9hI/AAAAAAAAD5k/IwAiQ3VkV4QXG0qlNqcbk9_QGAMSXF6CACLcB/s1600/Famous%2BQuotes%2B-%2BElvis%2BPresley.JPG" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="https://img.izismile.com/img/img5/20120330/640/inspirational_quotes_of_famous_people_640_01.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="http://wonderfulengineering.com/wp-content/uploads/2016/03/famous-quotes-9.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="https://www.yourtango.com/sites/default/files/styles/header_slider/public/display_list/lovebreakupquotesmain.jpg?itok=Ua2zeD6v" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="https://fastertomaster.com/wp-content/uploads/2018/07/growth-mindset-quotes-audrey-hepburn.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="https://www.habitsforwellbeing.com/wp-content/uploads/2012/08/slide.071-e1417689645688-500x315.jpg" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="https://www.process.st/wp-content/uploads/2016/11/productivity-quotes-Einstein-final.gif" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="http://blog.rescuetime.com/wp-content/uploads/2017/12/be-not-afraid-of-going-slowly.png" alt="quote" style="width:50%; height: 50%">
</div>
<div class='a'>
<img src="https://pilbox.themuse.com/image.png?url=https%3A%2F%2Fassets.themuse.com%2Fuploaded%2Fattachments%2F24482.png%3Fv%3D7172e4ebdd96c84c78219b39db2dbd74e688108b7813a2c8d20e24d588f47b92&prog=1&w=780" alt="quote" style="width:50%; height: 50%">
</div>
<button onclick="window.location.href='index.php'">BACK</button>

</center>
</body>
</html> 
