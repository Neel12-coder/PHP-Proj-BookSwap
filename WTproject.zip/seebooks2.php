<?php 
session_start();
$connect = mysqli_connect('localhost','root','');
mysqli_select_db($connect,'bookswap');
if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$count = count($_SESSION["shopping_cart"]);
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_nameofbook'			=>	$_POST["hidden_name"],
				'item_price'		=>	$_POST["hidden_price"],
                'item_quality'		=>	$_POST["hidden_quality"],
                'item_nameofseller' =>  $_POST["hidden_nameofseller"],
                'item_sellerscontactno' => $_POST["hidden_sellerscontactno"]
			);
			$_SESSION["shopping_cart"][$count] = $item_array;
		}
		else
		{
			echo '<script>alert("Book Already Added")</script>';
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_nameofbook'			=>	$_POST["hidden_name"],
			'item_price'		=>	$_POST["hidden_price"],
            'item_quality'		=>	$_POST["hidden_quality"],
            'item_nameofseller' =>  $_POST["hidden_nameofseller"],
            'item_sellerscontactno' => $_POST["hidden_sellerscontactno"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Book Removed")</script>';
				echo '<script>window.location="buy.php"</script>';
			}
		}
	}
}

?>
<!DOCTYPE html>
<html>
	<head>
		<title>Available books</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
       
	</head>
	<body>
		<br />
		<div class="container">
		<br /><br />
<center> <h1 style="color:green;font-family:Arial">Available Engineering Books</h1> </center>

<center> <h3 style="color:red;font-family:Arial">To buy any of these books please Login!!</h3> </center>
			<?php
				$query = "SELECT * FROM addbooks ORDER BY id ASC";
				$result = mysqli_query($connect, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
				?>
			<div class="col-md-4">
				<form method="post" action="buy.php?action=add&id=<?php echo $row["id"]; ?>">
					<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">

						<h4 class="text-info">Name of the book :<?php echo $row["nameofbook"]; ?></h4>
                                                 <h4 class="text-info">Name of the author :<?php echo $row["nameofauthor"]; ?></h4>
                                                 <h4 class="text-info">Quality :<?php echo $row["quality"]; ?></h4>
                                                 <h4 class="text-danger"> Price :Rs. <?php echo $row["price"]; ?></h4>
                                                 <!--<h4 class="text-info">Name Of Seller :<?php echo $row["nameofseller"]; ?></h4>
                                                 <h4 class="text-info">Seller's Contactno :<?php echo $row["sellerscontactno"]; ?></h4>-->

						<input type="hidden" name="hidden_name" value="<?php echo $row["nameofbook"]; ?>" />

						<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />
                        <input type="hidden" name="hidden_quality" value="<?php echo $row["quality"]; ?>" />
                        <input type="hidden" name="hidden_nameofseller" value="<?php echo $row["nameofseller"]; ?>" />
                        <input type="hidden" name="hidden_sellerscontactno" value="<?php echo $row["sellerscontactno"]; ?>" />


					</div>
				</form>
			</div>
			<?php
					}
				}
			?>
			<div style="clear:both"></div>
			<br />
            
            <center><button class="btn btn-success" onclick="window.location.href='dashlogout.php'">Back</button></center>
			</body>
</html>

<?php
//If you have use Older PHP Version, Please Uncomment this function for removing error 

/*function array_column($array, $column_name)
{
	$output = array();
	foreach($array as $keys => $values)
	{
		$output[] = $values[$column_name];
	}
	return $output;
}*/
?>