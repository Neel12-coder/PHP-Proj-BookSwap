<?php

session_start();


$con=mysqli_connect('localhost','root','');

mysqli_select_db($con,'bookswap');

$uname=$_POST['username'];
$pass=$_POST['password'];

$s="select * from register where username='$uname' && password='$pass'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);
if($num==1){
    $_SESSION['username']=$uname;
     header('location:dashlogout.php');
}
else{
header('location:login.php');

}
?>
