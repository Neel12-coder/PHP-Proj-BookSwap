<?php

session_start();
header('location:login.php');

$con=mysqli_connect('localhost','root','');

mysqli_select_db($con,'bookswap');

$pname=$_POST['personname'];
$add=$_POST['address'];
$contact=$_POST['contactno'];
$email=$_POST['email'];
$uname=$_POST['username'];
$pass=$_POST['password'];

$s="select * from register where username='$uname'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);
if($num==1){
echo "Username already taken";
}
else{
$reg="insert into register (name,address,contact,email,username,password) values ('$pname','$add','$contact','$email','$uname','$pass')";
mysqli_query($con,$reg);
echo "Registration successful";
}
?>
