<html>
<head>
<title>Contact Us</title>
<style>
body {
  background-image: url("https://images.pexels.com/photos/159621/open-book-library-education-read-159621.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500");
  background-color: #cccccc;

  background-repeat:no-repeat;
  background-size: cover; 
  width:100%;
  height:100%;
}
button {
    width: 30%;
    background-color: black;
    color: white;
    font-family: Times New Roman;
    font-size:20;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  button:hover {
    background-color: #2E4053;
  }
  

#para1 {
  text-align: left;
  font-family: Times New Roman;
  font-size: 50;
  font-weight: bold;
  color: black;
}
#para2 {
  text-align: left;
  font-family: Times New Roman;
  font-size: 35;
  font-weight: bold;
  color: black;
}
#para3 {
  text-align: left;
  font-family: Times New Roman;
  font-size: 25;
  font-weight: bold;
  color: black;
}
#para4 {
  text-align: left;
  font-family: Times New Roman;
  font-size: 25;
  font-weight: bold;
  color: black;
}
textarea{
  border: 1px solid black;
  }
input[type=submit] {
  width: 30%;
  background-color: black;
  color: white;
  font-family: Times New Roman;
  font-size:20;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
input[type=submit]:hover {
  background-color: #2E4053;
}
</style>
<script>
function thankalert()
{
alert("Thanks for letting us know! We shall get back to you!");
}
</script>
</head>
<body>
<p id="para1">Contact Us</p>
<p id="para2">
If you have any doubts or grievances, please feel free to contact us.<br>Before contacting us, please visit our <a href="aboutus1.php"><b>About Us</b></a> page.
</p>
<p id="para3">What would you like to tell us?</p>
<form id="contactQ" onsubmit="return thankalert()">
<textarea name="message" rows="10" cols="70" placeholder="Please tell us here" required></textarea>
<br><br>
<input type="submit" value="Submit Query">
<button onclick="window.location.href='index.php'">BACK</button>

</form>
<br><br><br>
<p id="para4">You can also let us know at our email ID <br> <font color="blue">bookswap@gmail.com</font> <br> Or give us a call at <br> <font color="blue">9804567898</font></p>
</body>
</html>