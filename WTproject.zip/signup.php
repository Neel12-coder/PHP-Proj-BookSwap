html>
<head>
<title>Sign Up</title>
<style>
body {
  background-image: url("https://images.pexels.com/photos/159621/open-book-library-education-read-159621.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500");
  background-color: #cccccc;
  background-repeat:no-repeat;
  background-size: cover; 
  width:100%;
  height:100%;
}

button {
    width: 30%;
    background-color: black;
    color: white;
    font-family: Times New Roman;
    font-size:20;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  button:hover {
    background-color: #2E4053;
  }
  


#P1 {
  font-family: Times New Roman;
  font-size: 50;
  font-weight: bold;
  color: black;
}
label{
font-family:Times New Roman;
font-size:25;
font-weight: bold;
color:black;
}
input[type=text], select {
  width: 40%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=password], select {
  width: 40%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=number], select {
  width: 40%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=email], select {
  width: 40%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 30%;
  background-color: black;
  color: white;
  font-family: Times New Roman;
  font-size:20;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
input[type=submit]:hover {
  background-color: #2E4053;
}
</style>
</head>
<body>
<form align="center" name="myForm" action="registerval.php" method="post">
<p id="P1">Sign Up</p>
<label for="personname">Name</label>
<input name="personname" type="text" required>
<br><br>
<label for="address">Address</label>
<input name="address" type="text" required>
<br><br>
<label for="contactno">Contact no.</label>
<input name="contactno" type="number" min="1000000000" max="9999999999" required>
<br><br>
<label for="email">Email</label>
<input name="email" type="email" required>
<br><br>
<label for="username">Username</label>
<input name="username" type="text" required>
<br><br>
<label for="password">Password</label>
<input id="pass" name="password" type="password" required min="8" max="30" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}">
<br><br>
<label for="confirmpassword">Confirm Password</label>
<input id="confirm_pass" name="confirmpassword" type="password"  required> 
<br><br>
<input type="submit" value="Sign Up" onclick="alert('Registered Successfully')">
<button onclick="window.location.href='index.php'">CANCEL</button>
</form>
<script type="text/javascript">
          var password = document.getElementById("pass");
          confirm_password = document.getElementById("confirm_pass");
function validatePassword(){
          if(pass.value != confirm_pass.value) {
            confirm_pass.setCustomValidity("Passwords Don't Match");
          } else {
            confirm_pass.setCustomValidity('');
          }
        }
        password.onchange = validatePassword;
        confirm_pass.onkeyup = validatePassword;
    </script>
</body>
</html>