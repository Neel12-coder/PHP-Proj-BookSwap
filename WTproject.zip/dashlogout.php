<!DOCTYPE html>
<?php 
session_start();
if(!isset($_SESSION['username'])){
    header('location:dashlogout.php');
}
?>


<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial;
  margin: 0;
}
.button1 {border-radius: 50%;}
.button2 {
  background-color: black; /* Green */
  border: none;
  color: white;
  padding: 35px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  margin: 4px 2px;
  cursor: pointer;
}
.button2:hover {
  background-color: #2E4053;
}

.button {
  background-color: black;
  border: none;
  color: white;
  padding: 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.button:hover {
  background-color: #2E4053;
}



    /* navbar */
    #navbar ul{
      list-style-type: none;
      padding: 50;
      overflow: hidden;
      background-color: #333;
	  margin-top: 0px;
	  margin-bottom: 10px;
   

	
    }

    #navbar li{
      float: left;
    }

    #navbar li a{
      display: block;
      font-family:Verdana, Geneva, Tahoma, sans-serif;
      color: white;
      text-align: center;
      padding: 25px 16px;
      text-decoration: none;
    }

    #navbar li a:hover:not(.active){
      background-color: black;
    }

    #navbar .active{
      background-color: white;
      color:#FF0000;
    }
      
    /*endnavbar*/
	


* {
  box-sizing: border-box;
}

img {
  vertical-align: middle;
}

/* Position the image container (needed to position the left and right arrows) */
.container {
  position: relative;
}

/* Hide the images by default */
.mySlides {
  display: none;
}

/* Add a pointer when hovering over the thumbnail images */
.cursor {
  cursor: pointer;
}

/* Next & previous buttons */
.prev,
.next {
  cursor: pointer;
  position: absolute;
  top: 40%;
  width: auto;
  padding: 16px;
  margin-top: -50px;
  color: white;
  font-weight: bold;
  font-size: 20px;
  border-radius: 0 3px 3px 0;
  user-select: none;
  -webkit-user-select: none;
}
.next1 {
  cursor: pointer;
  position: absolute;
  top: 80%;
  width: auto;
  padding: 50px;
  margin-top: -750px;
  left:80%;
  color: white;
  background-color:#f2f2f2;
  font-weight: bold;
  font-size: 20px;
  border-start-end-radius:50px;
  user-select: none;
  -webkit-user-select: none;
}
.next2 {
  cursor: pointer;
  position: absolute;
  top: 80%;
  width: auto;
  padding: 50px;
  left:80%;
  margin-top: -550px;
  color: white;
  font-weight: bold;
  font-size: 20px;
  border-start-end-radius:50px;
  user-select: none;
  -webkit-user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover,
.next:hover {
  background-color: rgba(0, 0, 0, 0.8);
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* Container for image text */
.caption-container {
  text-align: center;
  background-color: #222;
  padding: 2px 16px;
  color: white;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Six columns side by side */
.column {
  float: left;
  width: 16.66%;
}

/* Add a transparency effect for thumnbail images */
.demo {
  opacity: 0.6;
}

.active,
.demo:hover {
  opacity: 1;
}
</style>
<body>
 <div class=container>
  <div id="navbar">
      <ul>
        <div id="leftnav">
        <li><h2 style="color:white">BOOK SWAP</h2></li>
         <li><a href="{% url 'howitworks' %}">See Eng Books</a></li>
         <li><a href="{% url 'howitworks' %}">How It Works</a></li>
         <li><a href="aboutus2.php">About Us</a></li>
		    </div>
          <div id="rightnav">
     <li style="float:right" ><h3 style="color:red"> WELCOME <?php echo $_SESSION['username']; ?></h3></li>
        <li style="float:right"><a href="index.php">LOGOUT</a></li>
      </div>
      <br>
      <br>
      <br>


<div class="container">
  <div class="mySlides">
    <div class="numbertext">1 / 6</div>
    <img src="https://images.pexels.com/photos/1130980/pexels-photo-1130980.jpeg?cs=srgb&dl=assortment-book-bindings-books-1130980.jpg&fm=jpg" style="width:100%">
  </div>

  <div class="mySlides">
    <div class="numbertext">2 / 6</div>
    <img src="https://images.pexels.com/photos/1319854/pexels-photo-1319854.jpeg?cs=srgb&dl=architecture-book-shelves-bookcase-1319854.jpg&fm=jpg" style="width:100%">
  </div>

  <div class="mySlides">
    <div class="numbertext">3 / 6</div>
    <img src="https://images.pexels.com/photos/207662/pexels-photo-207662.jpeg?cs=srgb&dl=book-shelves-book-stack-bookcase-207662.jpg&fm=jpg" style="width:100%">
  </div>
    
  <div class="mySlides">
    <div class="numbertext">4 / 6</div>
    <img src="https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" style="width:100%">
  </div>

  <div class="mySlides">
    <div class="numbertext">5 / 6</div>
    <img src="https://images.pexels.com/photos/459791/pexels-photo-459791.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" style="width:100%">
  </div>
    
  <div class="mySlides">
    <div class="numbertext">6 / 6</div>
    <img src="https://images.pexels.com/photos/415078/pexels-photo-415078.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" style="width:100%">
  </div>
    
  <a class="prev" onclick="plusSlides(-1)">❮</a>
  <a class="next" onclick="plusSlides(1)">❯</a>
<a class="next1 button1 button2" ><input type="button" value="BUY" onclick="window.location.href='buy.php'"></a>
<a class="next2 button1 button2" ><input type="button" value="SELL" onclick="window.location.href='sellbook.php'"></a>
  <div class="caption-container">
    <p id="caption"></p>
  </div>

  <div class="row">
    <div class="column">
      <img class="demo cursor" src="https://images.pexels.com/photos/1130980/pexels-photo-1130980.jpeg?cs=srgb&dl=assortment-book-bindings-books-1130980.jpg&fm=jpg" style="width:100%" onclick="currentSlide(1)" alt="Books are the treasured wealth of the world">
    </div>
    <div class="column">
      <img class="demo cursor" src="https://images.pexels.com/photos/1319854/pexels-photo-1319854.jpeg?cs=srgb&dl=architecture-book-shelves-bookcase-1319854.jpg&fm=jpg" style="width:100%" onclick="currentSlide(2)" alt="There is no friend as loyal as a book">
    </div>
    <div class="column">
      <img class="demo cursor" src="https://images.pexels.com/photos/207662/pexels-photo-207662.jpeg?cs=srgb&dl=book-shelves-book-stack-bookcase-207662.jpg&fm=jpg" style="width:100%" onclick="currentSlide(3)" alt="Reading gives us some place to go when we have to stay where we are">
    </div>
    <div class="column">
      <img class="demo cursor" src="https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" style="width:100%" onclick="currentSlide(4)" alt="Books are the most loyal and trusted friends you can ever have">
    </div>
    <div class="column">
      <img class="demo cursor" src="https://images.pexels.com/photos/459791/pexels-photo-459791.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" style="width:100%" onclick="currentSlide(5)" alt="A book is a dream that you hold in your hands">
    </div>    
    <div class="column">
      <img class="demo cursor" src="https://images.pexels.com/photos/415078/pexels-photo-415078.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" style="width:100%" onclick="currentSlide(6)" alt="The journey of lifetime starts with the turning of a page">
    </div>
  </div>
  
</div>
<center>
<div>
<footer>
<button class="button button1" onclick="window.location.href='contactus2.php'">Contact Us</button>
<button class="button button1">Privacy Policy</button>
<button class="button button1" onclick="window.location.href='quotes2.php'">Quotes</button>
</footer>
</div>
</center>


<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>
    
</body>
</html>
