<html>
<head>
<title>Sell your books</title>
<style>
body {
  background-image: url("https://images.pexels.com/photos/159621/open-book-library-education-read-159621.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500");
  background-color: #cccccc;
  background-repeat:no-repeat;
  background-size: cover; 
  width:100%;
  height:100%;
}

button {
    width: 30%;
    background-color: black;
    color: white;
    font-family: Times New Roman;
    font-size:20;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  button:hover {
    background-color: #2E4053;
  }
  


#P1 {
  font-family: Times New Roman;
  font-size: 50;
  font-weight: bold;
  color: black;
}
label{
font-family:Times New Roman;
font-size:25;
font-weight: bold;
color:black;
}
input[type=text], select {
  width: 40%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=password], select {
  width: 40%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 30%;
  background-color: black;
  color: white;
  font-family: Times New Roman;
  font-size:20;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
input[type=submit]:hover {
  background-color: #2E4053;
}
</style>
<body>
<form align="center" name="myForm" action="sellval.php" method="post">
<p id="P1">Want to sell your old books??</p>
<label for="semester">Semester</label>
<input name="semester" type="text" required>
<br><br>
<label for="nameofbook">Name of book</label>
<input name="nameofbook" type="text" required>
<br><br>
<label for="nameofauthor">Name of the author</label>
<input name="nameofauthor" type="text" required>
<br><br>
<label for="price">Price</label>
<input name="price" type="text" required>
<br><br>
<label for="quality">Quality[Best/Average/Poor]</label>
<input name="quality" type="text" required>
<br><br>
<label for="nameofseller">Seller's Name</label>
<input name="nameofseller" type="text" required>

<br><br>
<label for="sellerscontactno">Seller's Contact No.</label>
<input name="sellerscontactno" type="text" required>
<br><br>
<input type="submit" value="Add" onclick="alert('book Added Successfully')">
<button onclick="window.location.href='dashlogout.php'">CANCEL</button>

</form>
</body>
</html>